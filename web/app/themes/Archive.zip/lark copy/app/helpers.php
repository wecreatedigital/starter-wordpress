<?php

/**
 * Theme helpers.
 */

namespace App;
