<?php (dynamic_sidebar('sidebar-primary')); ?>
<?php /**PATH /Users/dac/Sites/roots/wp-content/themes/sage/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>