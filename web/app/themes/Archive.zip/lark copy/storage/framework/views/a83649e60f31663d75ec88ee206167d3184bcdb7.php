<header class="banner">
  <div class="container">
    <a class="brand" href="<?php echo e(home_url('/')); ?>">
      <?php echo e($siteName); ?>

    </a>

    <nav class="nav-primary">
      <?php if(has_nav_menu('primary_navigation')): ?>
        <?php echo wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav', 'echo' => false]); ?>

      <?php endif; ?>
    </nav>
  </div>
</header>
<?php /**PATH /Users/dac/Sites/roots/wp-content/themes/lark/resources/views/partials/header.blade.php ENDPATH**/ ?>