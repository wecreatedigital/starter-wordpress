<footer class="content-info">
  <div class="container">
    <?php (dynamic_sidebar('sidebar-footer')); ?>
  </div>
</footer>
<?php /**PATH /Users/dac/Sites/roots/wp-content/themes/sage/resources/views/partials/footer.blade.php ENDPATH**/ ?>