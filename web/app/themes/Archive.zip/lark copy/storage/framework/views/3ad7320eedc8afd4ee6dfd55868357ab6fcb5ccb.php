<div class="alert alert-<?php echo e($type); ?>">
  <?php echo $message ?? $slot; ?>

</div>
<?php /**PATH /Users/dac/Sites/roots/wp-content/themes/sage/resources/views/components/alert.blade.php ENDPATH**/ ?>