<div class="page-header">
  <h1><?php echo $title; ?></h1>
</div>
<?php /**PATH /Users/dac/Sites/roots/wp-content/themes/lark/resources/views/partials/page-header.blade.php ENDPATH**/ ?>