<?php (dynamic_sidebar('sidebar-primary')); ?>
<?php /**PATH /Users/dac/Sites/roots/wp-content/themes/lark/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>