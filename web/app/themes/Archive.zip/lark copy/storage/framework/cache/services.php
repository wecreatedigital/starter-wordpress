<?php return array (
  'providers' => 
  array (
    0 => 'App\\Providers\\ThemeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\Providers\\ThemeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);