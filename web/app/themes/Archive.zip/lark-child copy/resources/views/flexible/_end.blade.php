  @hassub('container_type')
    </div>
  @endsub
</section>
