@extends('layouts.app')

@section('content')
  @include('flexible._main')
@endsection
