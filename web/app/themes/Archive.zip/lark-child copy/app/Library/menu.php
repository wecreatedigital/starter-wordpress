<?php

/**
 * Custom footer menu https://codex.wordpress.org/Function_Reference/register_nav_menus
 */
register_nav_menus([
    'footer_navigation' => __('Footer Navigation', 'sage'),
]);
