<?php return array (
  'log1x/sage-svg' => 
  array (
    'providers' => 
    array (
      0 => 'Log1x\\SageSvg\\SageSvgServiceProvider',
    ),
  ),
);