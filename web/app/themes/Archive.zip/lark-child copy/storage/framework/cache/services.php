<?php return array (
  'providers' => 
  array (
    0 => 'Log1x\\SageSvg\\SageSvgServiceProvider',
    1 => 'App\\Providers\\ThemeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Log1x\\SageSvg\\SageSvgServiceProvider',
    1 => 'App\\Providers\\ThemeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);