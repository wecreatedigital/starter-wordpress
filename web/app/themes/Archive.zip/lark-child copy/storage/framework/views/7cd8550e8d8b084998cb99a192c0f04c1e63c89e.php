<?php echo $__env->make('flexible._start', [
  'classes' => 'fcb-gallery pb-0',
  'padding' => $default_padding,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
  <div class="offset-lg-2 col-lg-8 text-center">
    <?php echo $__env->make('flexible.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

<div class="row fcb-t40 no-gutters justify-content-md-center">
  <?php if (have_rows('gallery')) : ?><?php while (have_rows('gallery')) : the_row(); ?>
    <img loading="lazy" src="<?= get_sub_field('image')['sizes']['large']; ?>" alt="<?= get_sub_field('image')['alt']; ?>" class="col-6 col-sm-6 col-md-4 img-fluid">
  <?php endwhile; endif; ?>
</div>

<?php echo $__env->make('flexible._end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/gallery-block.blade.php ENDPATH**/ ?>