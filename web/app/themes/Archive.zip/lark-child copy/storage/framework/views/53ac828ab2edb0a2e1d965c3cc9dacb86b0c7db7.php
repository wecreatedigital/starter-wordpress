<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('flexible._main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/front-page.blade.php ENDPATH**/ ?>