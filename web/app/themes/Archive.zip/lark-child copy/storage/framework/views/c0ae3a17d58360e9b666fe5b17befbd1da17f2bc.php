<?php
  $position = get_sub_field('image_position');
  $url = '';
  $background_image = get_sub_field('image');
  if( $background_image ) {
    $url = $background_image['sizes']['large_square'];
  }
?>

<?php echo $__env->make('flexible._start', [
  'classes' => 'fcb-left-image-right-text',
  'padding' => 0,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
  <div class="<?php if (get_sub_field('padding_override')) : ?><?php echo e('fcb-'); ?><?= get_sub_field('padding_override'); ?><?php echo e('100'); ?><?php endif; ?> col-sm-12 col-md-7 <?php if( $position == "left" ): ?> order-2 <?php else: ?> order-2 order-sm-2 order-md-1 <?php endif; ?>">
    <?php echo $__env->make('flexible.content', [
      'classes' => ''
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <div style="background-image: url(<?php echo e($url); ?>)" class="fcb-col-image col-sm-12 col-md-5 <?php if( $position == "left" ): ?> order-1 <?php else: ?> order-1 order-sm-1 order-md-2 <?php endif; ?>"></div>
</div>

<?php echo $__env->make('flexible._end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/left-right-image-text-block.blade.php ENDPATH**/ ?>