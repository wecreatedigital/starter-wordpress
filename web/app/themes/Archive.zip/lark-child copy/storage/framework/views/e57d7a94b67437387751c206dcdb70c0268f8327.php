<?php
  $h = 1; // Heading for SEO
  $unique_id = 1; // For counting the number of accordions
  $default_padding = 100;
?>

<?php if (have_rows('page_content_block')) : ?><?php while (have_rows('page_content_block')) : the_row(); ?>

<?php if (get_row_layout() === 'text_block') : ?>
    <?php echo $__env->make('flexible.text-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'image_block') : ?>
    <?php echo $__env->make('flexible.image-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'hero_block') : ?>
    <?php echo $__env->make('flexible.hero-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'left_right_image_text_block') : ?>
    <?php echo $__env->make('flexible.left-right-image-text-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'latest_block') : ?>
    <?php echo $__env->make('flexible.latest-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'donate_block') : ?>
    <?php echo $__env->make('flexible.donate-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'gallery_block') : ?>
    <?php echo $__env->make('flexible.gallery-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'contact_block') : ?>
    <?php echo $__env->make('flexible.contact-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'accordion_block') : ?>
    <?php echo $__env->make('flexible.accordion-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'card_block') : ?>
    <?php echo $__env->make('flexible.card-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'icon_block') : ?>
    <?php echo $__env->make('flexible.icon-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if (get_row_layout() === 'testimonial_block') : ?>
    <?php echo $__env->make('flexible.testimonial-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php
  $h++;
  $unique_id++;
?>

<?php endwhile; endif; ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/_main.blade.php ENDPATH**/ ?>