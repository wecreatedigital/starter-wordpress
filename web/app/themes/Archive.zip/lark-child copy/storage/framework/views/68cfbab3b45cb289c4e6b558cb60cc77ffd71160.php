<?php echo $__env->make('flexible._start', [
  'classes' => 'fcb-accordion',
  'padding' => $default_padding,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row no-gutters">
  <div class="fcb-col-center fcb-align-text col-md-8">
    <?php echo $__env->make('flexible.content', [
      'classes' => 'fcb-b30 fcb-x70'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

<div class="container">
  <div class="panel-group accordion" id="accordion-<?php echo e($unique_id); ?>" role="tablist" aria-multiselectable="true">
    <div class="row no-gutters">
      <div class="col-md-10 offset-md-1">
        <?php $i=1; while ( have_rows('accordion_item') ) : the_row() ?>
          <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading-<?php echo e($unique_id); ?>-<?php echo e($i); ?>">
              <h3 class="panel-title">
                <button class="fcb-y40" data-toggle="collapse" data-target="#collapse-<?php echo e($unique_id); ?>-<?php echo e($i); ?>" href="#collapse-<?php echo e($unique_id); ?>-<?php echo e($i); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($unique_id); ?>-<?php echo e($i); ?>">
                  <?= get_sub_field('heading'); ?>
                  <svg xmlns="http://www.w3.org/2000/svg" class="plus <?php if ($i==1) { echo 'minus'; } ?>" width="15" height="15" viewBox="0 0 15 15">
                    <rect class="vertical-line" x="7" width="2" height="15"/>
                    <rect class="horizontal-line" y="7" width="15" height="2"/>
                  </svg>
                </button>
              </h3>
            </div>
            <div id="collapse-<?php echo e($unique_id); ?>-<?php echo e($i); ?>" data-parent="#accordion-<?php echo e($unique_id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-<?php echo e($unique_id); ?>-<?php echo e($i); ?>">
              <div class="panel-body fcb-a40">
                <?= get_sub_field('text'); ?>
              </div>
            </div>
          </div>
        <?php $i++; endwhile; ?>
      </div>
    </div>
  </div>
</div>

<?php if( get_sub_field('call_to_action') ): ?>
  <div class="row no-gutters">
    <div class="fcb-col-center fcb-align-text col-md-8">
      <p class="lead fcb-t50">
        <?php if (get_sub_field('call_to_action')) : ?>
          <a target="<?= get_sub_field('call_to_action')['target']; ?>" class="btn-link btn-lg" href="<?= get_sub_field('call_to_action')['url']; ?>">
            <?= get_sub_field('call_to_action')['title']; ?>
          </a>
        <?php endif; ?>
      </p>
    </div>
  </div>
<?php endif; ?>

<?php echo $__env->make('flexible._end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/accordion-block.blade.php ENDPATH**/ ?>