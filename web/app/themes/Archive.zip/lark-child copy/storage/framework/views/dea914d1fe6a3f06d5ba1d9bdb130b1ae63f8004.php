  <?php if (get_sub_field('container_type')) : ?>
    </div>
  <?php endif; ?>
</section>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/_end.blade.php ENDPATH**/ ?>