<?php $__env->startSection('content'); ?>
  <div class="jumbotron">
    <div class="container">
      <h1 class="display-4">
        Sorry - this page cannot be found!
      </h1>
      <?= get_field('supporting_text_1', 'option'); ?>
      <hr class="my-4">
      <?= get_field('supporting_text_2', 'option'); ?>
      <?php ( $post_objects = get_field('commonly_used_pages', 'options') ); ?>
        <?php if( $post_objects ): ?>
          <h5>
            Other popular pages:
          </h5>
          <ul>
            <?php $__currentLoopData = $post_objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <a href="<?php echo e(get_permalink($post_object->ID)); ?>">
                  <?php echo e(get_the_title($post_object->ID)); ?>

                </a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        <?php endif; ?>

      <?php if(! have_posts()): ?>
        <?php echo get_search_form(false); ?>

      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/404.blade.php ENDPATH**/ ?>