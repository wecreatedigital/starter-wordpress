<header>
  <nav class="navbar navbar-expand-md navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(get_home_url()); ?>">
        <?php echo e($siteName); ?>

      </a>
      <button class="btn skip-to-content-link" data-target="#main">
        Skip to content
      </button>
      <?php if( ! env('DISABLE_HAMBURGER')): ?>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#hamburger-menu" aria-controls="hamburger-menu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <?php echo wp_nav_menu( array(
          'theme_location'    => 'primary_navigation',
          'depth'             => 2,
          'container'         => 'div',
          'container_class'   => 'collapse navbar-collapse',
          'container_id'      => 'hamburger-menu',
          'menu_class'        => 'nav navbar-nav',
          'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
          'walker'            => new WP_Bootstrap_Navwalker(),
        ) );; ?>

      <?php else: ?>
        <a class="d-sm-block d-md-none" href="<?= get_field('header_call_to_action_link', 'option'); ?>">
          Contact
        </a>
        <?php echo wp_nav_menu( array(
          'theme_location'    => 'primary_navigation',
          'depth'             => 1,
          'container'         => 'div',
          'container_class'   => 'mobile-first-menu',
          'container_id'      => '',
          'menu_class'        => 'nav d-flex',
          'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
          'walker'            => new WP_Bootstrap_Navwalker(),
        ) );; ?>

      <?php endif; ?>
  	</div>
  </nav>
</header>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/layouts/header.blade.php ENDPATH**/ ?>