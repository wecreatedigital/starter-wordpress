<footer class="content-info">
  <div class="container">
    <?php (dynamic_sidebar('sidebar-footer')); ?>
  </div>
</footer>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/layouts/footer.blade.php ENDPATH**/ ?>