<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="main" id="main">
  <?php echo $__env->make('layouts.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('content'); ?>
</main>

<?php if (! empty(trim($__env->yieldContent('sidebar')))): ?>
  <aside class="sidebar">
    <?php echo $__env->yieldContent('sidebar'); ?>
  </aside>
<?php endif; ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('helpers.dev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/layouts/app.blade.php ENDPATH**/ ?>