<div class="quote-item mb-50">
  <div class="row justify-content-center">
    <div class="quote-left">
      <?php echo e(get_svg('svg.quote-left', get_sub_field('quote_colour'))); ?>
    </div>
    <div class="p-sm-3 text-center quote-text">
      <p>
        <span>
          <?php the_content(); ?>
        </span>
      </p>
      <p class="quote-author">
        <?= get_the_title(); ?>
      </p>
    </div>
    <div class="quote-right">
      <?php echo e(get_svg('svg.quote-right', get_sub_field('quote_colour'))); ?>
    </div>
  </div>
</div>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/partials/testimonial.blade.php ENDPATH**/ ?>