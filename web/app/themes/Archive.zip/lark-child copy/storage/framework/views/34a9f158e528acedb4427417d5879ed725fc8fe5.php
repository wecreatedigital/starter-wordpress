<?php
  $url = '';
  $background_image = get_sub_field('background');
  if( $background_image ) {
    $url = $background_image['url'];
  }
?>

<?php echo $__env->make('flexible._start', [
  'classes' => 'fcb-hero fcb-v-align',
  'padding' => $default_padding,
  'style' => 'background-image: url('.$url.')',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
  <div class="fcb-col-<?= get_sub_field('column_offset'); ?> <?php if (get_sub_field('align_text')) : ?><?php echo e('fcb-align-text'); ?><?php endif; ?> col-md-8">
    <?php echo $__env->make('flexible.content', [
      'classes' => ''
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

<div class="overlay"></div>

<?php echo $__env->make('flexible._end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/hero-block.blade.php ENDPATH**/ ?>