<?php echo $__env->make('flexible._start', [
  'classes' => 'fcb-contact',
  'padding' => $default_padding,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
  <div class="offset-lg-2 col-lg-8 text-center">
    <?php echo $__env->make('flexible.content', [
      'classes' => 'fcb-b40'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

<div class="row">
  <div class="offset-lg-2 col-lg-8">
    <?php echo do_shortcode('[contact-form-7 id="'.get_sub_field('contact_form').'" title="Contact"]'); ?>

  </div>
</div>

<?php if (get_sub_field('contact_form_redirect')) : ?>
<script>
  document.addEventListener( 'wpcf7mailsent', function( event ) {
    location = '<?= get_sub_field('contact_form_redirect'); ?>' ;
  }, false );
</script>
<?php endif; ?>


<?php echo $__env->make('flexible._end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/contact-block.blade.php ENDPATH**/ ?>