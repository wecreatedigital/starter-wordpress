<?php
  if( $h == 1 ) {
    $heading = 'h1';
    $sub_heading = 'h2';
  } elseif( $h >= 2 && $h <= 4 ) {
    $heading = 'h2';
    $sub_heading = 'h3';
  } else {
    $heading = 'h3';
    $sub_heading = 'h4';
  }
?>

<div class="content <?php if( isset($classes) ): ?> <?php echo e($classes); ?> <?php else: ?> fcb-b20 <?php endif; ?>">
  <?php if (get_sub_field('heading')) : ?>
    <<?php echo e($heading); ?> class="mb-3">
      <?= get_sub_field('heading'); ?>
    </<?php echo e($heading); ?>>
  <?php endif; ?>

  <?php if (get_sub_field('sub_heading')) : ?>
    <<?php echo e($sub_heading); ?> class="mb-3">
      <?= get_sub_field('sub_heading'); ?>
    </<?php echo e($sub_heading); ?>>
  <?php endif; ?>

  <?php if (get_sub_field('text')) : ?>
    <?= get_sub_field('text'); ?>
  <?php endif; ?>

  <?php if( get_sub_field('primary_call_to_action') || get_sub_field('secondary_call_to_action') ): ?>
    <p class="lead">
      <?php if (get_sub_field('primary_call_to_action')) : ?>
        <a target="<?= get_sub_field('primary_call_to_action')['target']; ?>" class="btn btn-lg" href="<?= get_sub_field('primary_call_to_action')['url']; ?>"><?= get_sub_field('primary_call_to_action')['title']; ?></a>
      <?php endif; ?>
      <?php if (get_sub_field('secondary_call_to_action')) : ?>
        <a target="<?= get_sub_field('secondary_call_to_action')['target']; ?>" class="btn-link btn-lg" href="<?= get_sub_field('secondary_call_to_action')['url']; ?>"><?= get_sub_field('secondary_call_to_action')['title']; ?></a>
      <?php endif; ?>
    </p>
  <?php endif; ?>
</div>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/content.blade.php ENDPATH**/ ?>