<?php if( function_exists('yoast_breadcrumb') && ! have_rows('page_content_block') && ! is_404() ): ?>
  <div class="container">
    <?php echo yoast_breadcrumb( '<p id="breadcrumbs">','</p>' ); ?>

  </div>
<?php endif; ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/layouts/breadcrumbs.blade.php ENDPATH**/ ?>