<section
  <?php if( isset($style) ): ?>style="<?php echo e($style); ?>"<?php endif; ?>
  <?php if (get_sub_field('id')) : ?>id="<?php echo e(str_replace(' ', '-', preg_replace('/\s+/', ' ', strtolower(get_sub_field('id'))))); ?>"<?php endif; ?>
  class="fcb <?php if( isset($classes) ): ?><?php echo e($classes); ?><?php endif; ?>
  <?php if (get_sub_field('padding_override')) : ?><?php echo e('fcb-'); ?><?= get_sub_field('padding_override'); ?><?php echo e($padding); ?><?php endif; ?>
  <?php if (get_sub_field('background_colour')) : ?><?php echo e('fcb-'); ?><?= get_sub_field('background_colour'); ?><?php endif; ?>
">
  <?php if (get_sub_field('container_type')) : ?>
    <div class="<?= get_sub_field('container_type'); ?>">
  <?php endif; ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/_start.blade.php ENDPATH**/ ?>