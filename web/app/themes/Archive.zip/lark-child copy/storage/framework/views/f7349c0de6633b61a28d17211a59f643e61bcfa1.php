<?php echo $__env->make('flexible._start', [
  'classes' => 'fcb-testimonial',
  'padding' => $default_padding,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row no-gutters">
  <div class="fcb-col-center fcb-align-text col-md-8">
    <?php echo $__env->make('flexible.content', [
      'classes' => ''
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

<div class="container">
  <div class="testimonial-slick-slider">
    <?php
      $post_objects = get_sub_field('testimonials')
    ?>
    <?php if( $post_objects ): ?>
      <?php $__currentLoopData = $post_objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          setup_postdata($GLOBALS['post'] =& $post);
        ?>
        <?php echo $__env->make("partials.testimonial", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php
        wp_reset_postdata();
      ?>
    <?php endif; ?>
  </div>
</div>

<?php echo $__env->make('flexible._end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/dac/Sites/starter/web/app/themes/lark-child/resources/views/flexible/testimonial-block.blade.php ENDPATH**/ ?>